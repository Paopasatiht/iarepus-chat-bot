TO create chatbot there are 4 steps inside.
1) Theory + NLP Concepts ( stemming, tokenization, bag of words )
2) Create training data
3) PyTorch model and training
4) Save/load model and implement the chat